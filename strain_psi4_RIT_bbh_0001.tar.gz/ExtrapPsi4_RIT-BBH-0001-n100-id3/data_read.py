import numpy as np
import pylab

for l in range(2,3+1):
    for m in range(-l, l+1):
        print "(l,m) = ", l, m
        data = np.loadtxt("rPsi4_l"+str(l)+"_m"+str(m)+"_rInf.asc")
        datafile_path="./"
        datafile_path="./rPsi4_l"+str(l)+"_m"+str(m)+".dat"
        datafile_id=open(datafile_path, 'w+')
        data_short = (data[:,0], data[:,1], data[:,2])
        data_array=np.array(data_short)
        data_array=data_array.T
        data_array.shape
        np.savetxt(datafile_id, data_array, fmt=['%8.5f','%.17e', '%.17e'])
        datafile_id.close()
